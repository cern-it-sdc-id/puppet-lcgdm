## puppet-lcgdm module
[![Puppet Forge](http://img.shields.io/puppetforge/v/lcgdm/lcgdm.svg)](https://forge.puppetlabs.com/lcgdm/lcgdm)
[![Build Status](https://travis-ci.org/cern-it-sdc-id/puppet-lcgdm.svg?branch=master)](https://travis-ci.org/cern-it-sdc-id/puppet-lcgdm)

This is the puppet-lcgdm module, it configures the DPM/LFC legacy components developed at CERN , IT-SDC-ID section

### License
ASL 2.0

### Contact
Andrea Manzi <andrea.manzi@cern.ch>

## Support
Tickets and issues at our [cern-it-sdc-id site](https://github.com/cern-it-sdc-id)
